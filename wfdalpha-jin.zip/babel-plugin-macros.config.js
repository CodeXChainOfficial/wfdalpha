module.exports = {
    tailwind: {
        config: './tailwind.config.js',
        format: 'auto',
    },
}
