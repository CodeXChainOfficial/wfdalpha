// Imports


// Plugins
const plugins = [{
        location: "__react_static_root__/node_modules/react-static-plugin-sass",
        plugins: [],
        hooks: {}
      },
{
        location: "__react_static_root__/",
        plugins: [],
        hooks: {}
      }]

// Export em!
export default plugins