


// Template Map
export default {
  '__react_static_root__/src/pages/NotFound': require('__react_static_root__/src/pages/NotFound').default,
'__react_static_root__/src/pages/Index': require('__react_static_root__/src/pages/Index').default,
'__react_static_root__/src/pages/CreateProject': require('__react_static_root__/src/pages/CreateProject').default,
'__react_static_root__/src/pages/BackProject': require('__react_static_root__/src/pages/BackProject').default,
'__react_static_root__/src/pages/ExplorerProject': require('__react_static_root__/src/pages/ExplorerProject').default,
'__react_static_root__/src/pages/ProjectDetail': require('__react_static_root__/src/pages/ProjectDetail').default,
'__react_static_root__/src/pages/Invest_step1': require('__react_static_root__/src/pages/Invest_step1').default,
'__react_static_root__/src/pages/Invest_step2': require('__react_static_root__/src/pages/Invest_step2').default,
'__react_static_root__/src/pages/Invest_step3': require('__react_static_root__/src/pages/Invest_step3').default,
'__react_static_root__/src/pages/Invest_step4': require('__react_static_root__/src/pages/Invest_step4').default
}

export const notFoundTemplate = '__react_static_root__/src/pages/NotFound'

